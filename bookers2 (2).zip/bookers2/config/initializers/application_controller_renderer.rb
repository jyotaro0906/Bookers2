# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '4a24630fa9eaf7617aacf8c49b37753927647ea2277e108d3011548f5ce096d2a8f2fe0318314e1d534722deddcf2debbeb1f33c46bcb9cb50259dadc43e9800'